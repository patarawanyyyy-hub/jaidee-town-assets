Jaidee Thai font pack for Jaidee Town (Minecraft Java resource pack).
Based on the K2D font by Cadson Demak / The K2D Project Authors, SIL Open Font License 1.1 (see OFL.txt).
Change: Thai tone marks (U+0E48-U+0E4C) are raised by 330 units so they never overlap upper vowels,
because Minecraft draws glyphs without Thai mark positioning. Renamed to "Jaidee Thai" as the OFL asks.
Original pack: https://modrinth.com/resourcepack/k2d-font
